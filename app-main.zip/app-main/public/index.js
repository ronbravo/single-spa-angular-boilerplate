// import { notification } from 'https://cdnjs.cloudflare.com/ajax/libs/uikit/3.5.7/js/uikit-icons.min.js';
//
// console.log(notification);

import ('https://cdnjs.cloudflare.com/ajax/libs/uikit/3.5.7/js/uikit-icons.min.js').then(function() {
  console.log('*** HUH', [].slice.call(arguments))
})

// export class Bootup {
//   static async getConfig() {
//     // NOTE: Temporary result. Should hit some endpoint in the future.
//     return {
//       name: 'Main Setup',
//       modules: [
//         'runtime',
//         'polyfills',
//         'uikit',
//         // 'styles',
//         // 'vendor',
//       ]
//     }
//   }
//
//   static async start() {
//     let config;
//     config = await Bootup.getConfig();
//     // System.register(config.modules, function (_export, _context) {
//     //   return {
//     //     setters: [],
//     //     execute: function () {
//     //       console.log('App is ready.');
//     //     }
//     //   };
//     // });
//     // System.import('runtime');
//     // System.import('polyfills');
//     // System.import('uikit');
//     // System.import('app');
//   }
// }
//
// Bootup.start();


// import { test } from 'bob';
//
// console.log('WHAT:', test())

// <script src="./runtime.js"></script>
// <script src="./polyfills.js"></script>
// <script src="./styles.js"></script>
// <script src="./vendor.js"></script>
// <script src="./vendor.js"></script>
// <script src="./main.js"></script>

// window.define = function() {
//   console.log('WHAT:', [].slice.call(arguments));
// }
// window.define.amd = true;

// import './main.js';
// __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");

// import './static/experian/crosscore-ui/runtime-es2015.js';
// import './static/experian/crosscore-ui/polyfills-es2015.js';
// import 'https://cdnjs.cloudflare.com/ajax/libs/uikit/3.5.7/js/uikit.min.js';
// // import './static/experian/crosscore-ui/styles.js';
// // import './static/experian/crosscore-ui/vendor.js';
// import './static/experian/crosscore-ui/app-es2015.js';

// "bob": "./static/experian/crosscore-ui/bob.js",

// import './static/experian/crosscore-ui/runtime.js';
// import './static/experian/crosscore-ui/polyfills.js';
// import './static/experian/crosscore-ui/styles.js';
// import './static/experian/crosscore-ui/vendor.js';
// import './static/experian/crosscore-ui/vendor.js';
// import './static/experian/crosscore-ui/main.js';

// import ('./main.js');
// import ('https://cdnjs.cloudflare.com/ajax/libs/systemjs/6.6.1/system.min.js').then(() => {
//   // import ('https://cdn.jsdelivr.net/npm/slugify@1.4.5/slugify.min.js');
//   // import ('/static/experian/crosscore-ui/bob.js').then(() => {
//   // })
//   // System.import ('bob', [], '/static/experian/crosscore-ui/bob.js');
//   System.import ('bob');
// });
//
//
// System.import ('main').then (() => {});
