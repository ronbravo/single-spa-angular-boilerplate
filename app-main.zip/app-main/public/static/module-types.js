// import { errMsg } from '../err-msg.js';

function errMsg(errCode, msg) {
  if (process.env.SYSTEM_PRODUCTION)
    return (msg || "") + " (SystemJS https://git.io/JvFET#" + errCode + ")";
  else
    return (msg || "") + " (SystemJS Error#" + errCode + " " + "https://git.io/JvFET#" + errCode + ")";
}


(function(){/*
 * Interop for AMD modules to return the direct AMD binding instead of a
 * `{ default: amdModule }` object from `System.import`
 */
(function (global) {
  var systemJSPrototype = global.System.constructor.prototype;
  var originalImport = systemJSPrototype.import;

  systemJSPrototype.import = function () {
    return originalImport.apply(this, arguments).then(function (ns) {
      return ns.__useDefault ? ns.default : ns;
    });
  };
})(typeof self !== 'undefined' ? self : global);}());

/*
 * Loads JSON, CSS, Wasm module types based on file extensions
 * Supports application/javascript falling back to JS eval
 */
(function(global) {
  var systemJSPrototype = global.System.constructor.prototype;
  var instantiate = systemJSPrototype.instantiate;

  var moduleTypesRegEx = /\.(css|html|json|wasm)$/;
  systemJSPrototype.shouldFetch = function (url) {
    var path = url.split('?')[0].split('#')[0];
    var ext = path.slice(path.lastIndexOf('.'));
    return ext.match(moduleTypesRegEx);
  }
  systemJSPrototype.fetch = function (url) {
    return fetch(url);
  };

  systemJSPrototype.instantiate = function (url, parent) {
    var loader = this;
    if (this.shouldFetch(url)) {
      return this.fetch(url)
      .then(function (res) {
        if (!res.ok)
          throw Error(errMsg(7, process.env.SYSTEM_PRODUCTION ? [res.status, res.statusText, url, parent].join(', ') : res.status + ' ' + res.statusText + ', loading ' + url + (parent ? ' from ' + parent : '')));
        var contentType = res.headers.get('content-type');
        if (!contentType)
          throw Error(errMsg(4, process.env.SYSTEM_PRODUCTION ? [url, parent] : 'Missing header "Content-Type", loading ' + url + (parent ? ' from ' + parent : '')));
        if (contentType.match(/^(text|application)\/(x-)?javascript(;|$)/)) {
          return res.text().then(function (source) {
            (0, eval)(source);
            return loader.getRegister();
          });
        }
        else if (contentType.match(/^application\/json(;|$)/)) {
          return res.text().then(function (source) {
            return [[], function (_export) {
              return {
                execute: function () {
                  _export('default', JSON.parse(source));
                }
              };
            }];
          });
        }
        else if (contentType.match(/^text\/css(;|$)/)) {
          return res.text().then(function (source) {
            return [[], function (_export) {
              return {
                execute: function () {
                  // Relies on a Constructable Stylesheet polyfill
                  let dom = document.createElement('style');
                  dom.innerHTML = source;
                  document.body.appendChild(dom);

                  // var stylesheet = new CSSStyleSheet();
                  // stylesheet.replaceSync(source);
                  // _export('default', stylesheet);
                }
              };
            }];
          });
        }
        else if (contentType.match(/^application\/wasm(;|$)/)) {
          return (WebAssembly.compileStreaming ? WebAssembly.compileStreaming(res) : res.arrayBuffer().then(WebAssembly.compile))
          .then(function (module) {
            var deps = [];
            var setters = [];
            var importObj = {};

            // we can only set imports if supported (eg early Safari doesnt support)
            if (WebAssembly.Module.imports)
              WebAssembly.Module.imports(module).forEach(function (impt) {
                var key = impt.module;
                if (deps.indexOf(key) === -1) {
                  deps.push(key);
                  setters.push(function (m) {
                    importObj[key] = m;
                  });
                }
              });

            return [deps, function (_export) {
              return {
                setters: setters,
                execute: function () {
                  return WebAssembly.instantiate(module, importObj)
                  .then(function (instance) {
                    _export(instance.exports);
                  });
                }
              };
            }];
          });
        }
        else {
          throw Error(errMsg(4, process.env.SYSTEM_PRODUCTION ? contentType : 'Unknown module type "' + contentType + '"'));
        }
      });
    }
    return instantiate.apply(this, arguments);
  };
})(typeof self !== 'undefined' ? self : global);


// (function (global) {
//   const systemJSPrototype = global.System.constructor.prototype;
//   const transform = systemJSPrototype.transform;
//   systemJSPrototype.transform = function (url, source) {
//     // composition of transform is done based on assuming every format
//     // returns its own System.register. So we don't "compose" transforms
//     // but rather treat transforms "fallbacks" where they can select themselves
//     return Promise.resolve(transform.call(this, url, source))
//     .then(function (_source) {
//
//       // if there was translation done, then stop
//       if (source !== _source) {
//         return _source;
//       }
//
//       return new Promise((resolve, reject) => {
//         resolve(source);
//         console.log('*** HERE:', source);
//         return source;
//
//         // babel.transform(source, {
//         //   plugins: plugins,
//         //   sourceMaps: 'inline',
//         //   sourceFileName: url.split('/').pop()
//         // }, function (err, result) {
//         //   if (err)
//         //     reject(err);
//         //   else
//         //     resolve(result);
//         // });
//       })
//       .then(function (result) {
//         return result.code;
//       });
//     })
//   };
// })(typeof self !== 'undefined' ? self : global);
//
// // (function (global) {
// //   const systemJSPrototype = global.System.constructor.prototype;
// //   const transform = systemJSPrototype.transform;
// //   systemJSPrototype.transform = function (url, source) {
// //     // composition of transform is done based on assuming every format
// //     // returns its own System.register. So we don't "compose" transforms
// //     // but rather treat transforms "fallbacks" where they can select themselves
// //   //   return Promise.resolve(transform.call(this, url, source))
// //   //   .then(function (_source) {
// //   //     return _source;
// //   //
// //   //     // // if there was translation done, then stop
// //   //     // if (source !== _source)
// //   //     //   return _source;
// //   //     //
// //   //     // return new Promise((resolve, reject) => {
// //   //     //   resolve(_source);
// //   //     //
// //   //     // //   babel.transform(source, {
// //   //     // //     plugins: plugins,
// //   //     // //     sourceMaps: 'inline',
// //   //     // //     sourceFileName: url.split('/').pop()
// //   //     // //   }, function (err, result) {
// //   //     // //     if (err)
// //   //     // //       reject(err);
// //   //     // //     else
// //   //     // //       resolve(result);
// //   //     // //   });
// //   //     // // })
// //   //     // // .then(function (result) {
// //   //     // //   return result.code;
// //   //     // });
// //   //   })
// //   // };
// //
// //   // const existingHook = System.constructor.prototype.transform;
// //   // System.constructor.prototype.transform = function (args, car) {
// //   //   console.log('*** HERE:', args, car);
// //   //
// //   //   return Promise.resolve(existingHook.call(this, args))
// //   //   .then(function (existingHookResult, car) {
// //   //     console.log('*** HERE:', existingHookResult, car);
// //   //     // custom hook here
// //   //     return car;
// //   //   });
// //   // };
// // })(typeof self !== 'undefined' ? self : global);
//
// // (function(){function errMsg(errCode, msg) {
// //   return (msg || "") + " (SystemJS Error#" + errCode + " " + "https://git.io/JvFET#" + errCode + ")";
// // }/*
// //  * Loads JSON, CSS, Wasm module types based on file extensions
// //  * Supports application/javascript falling back to JS eval
// //  */
// // (function(global) {
// //   var systemJSPrototype = global.System.constructor.prototype;
// //   var instantiate = systemJSPrototype.instantiate;
// //
// //   var moduleTypesRegEx = /\.(css|html|json|wasm)$/;
// //   systemJSPrototype.shouldFetch = function (url) {
// //     var path = url.split('?')[0].split('#')[0];
// //     var ext = path.slice(path.lastIndexOf('.'));
// //     return ext.match(moduleTypesRegEx);
// //   };
// //   systemJSPrototype.fetch = function (url) {
// //     return fetch(url);
// //   };
// //
// //   systemJSPrototype.instantiate = function (url, parent) {
// //     var loader = this;
// //     if (this.shouldFetch(url)) {
// //       return this.fetch(url)
// //       .then(function (res) {
// //         if (!res.ok)
// //           throw Error(errMsg(7,  res.status + ' ' + res.statusText + ', loading ' + url + (parent ? ' from ' + parent : '')));
// //         var contentType = res.headers.get('content-type');
// //         if (!contentType)
// //           throw Error(errMsg(4,  'Missing header "Content-Type", loading ' + url + (parent ? ' from ' + parent : '')));
// //         if (contentType.match(/^(text|application)\/(x-)?javascript(;|$)/)) {
// //           return res.text().then(function (source) {
// //             (0, eval)(source);
// //             return loader.getRegister();
// //           });
// //         }
// //         else if (contentType.match(/^application\/json(;|$)/)) {
// //           return res.text().then(function (source) {
// //             return [[], function (_export) {
// //               return {
// //                 execute: function () {
// //                   _export('default', JSON.parse(source));
// //                 }
// //               };
// //             }];
// //           });
// //         }
// //         else if (contentType.match(/^text\/css(;|$)/)) {
// //           return res.text().then(function (source) {
// //             return [[], function (_export) {
// //               console.log('TRACE 1', _export.toString());
// //               return {
// //                 execute: function () {
// //                   // Relies on a Constructable Stylesheet polyfill
// //                   var stylesheet = new CSSStyleSheet();
// //                   stylesheet.replaceSync(source);
// //                   // console.log('TRACE 1', stylesheet, _export.toString());
// //                   document.adoptedStyleSheets = [...document.adoptedStyleSheets, stylesheet];
// //                   // _export('default', stylesheet);
// //                 }
// //               };
// //             }];
// //           });
// //         }
// //         else if (contentType.match(/^application\/wasm(;|$)/)) {
// //           return (WebAssembly.compileStreaming ? WebAssembly.compileStreaming(res) : res.arrayBuffer().then(WebAssembly.compile))
// //           .then(function (module) {
// //             var deps = [];
// //             var setters = [];
// //             var importObj = {};
// //
// //             // we can only set imports if supported (eg early Safari doesnt support)
// //             if (WebAssembly.Module.imports)
// //               WebAssembly.Module.imports(module).forEach(function (impt) {
// //                 var key = impt.module;
// //                 if (deps.indexOf(key) === -1) {
// //                   deps.push(key);
// //                   setters.push(function (m) {
// //                     importObj[key] = m;
// //                   });
// //                 }
// //               });
// //
// //             return [deps, function (_export) {
// //               return {
// //                 setters: setters,
// //                 execute: function () {
// //                   return WebAssembly.instantiate(module, importObj)
// //                   .then(function (instance) {
// //                     _export(instance.exports);
// //                   });
// //                 }
// //               };
// //             }];
// //           });
// //         }
// //         else {
// //           throw Error(errMsg(4,  'Unknown module type "' + contentType + '"'));
// //         }
// //       });
// //     }
// //     return instantiate.apply(this, arguments);
// //   };
// // })(typeof self !== 'undefined' ? self : global);}());
