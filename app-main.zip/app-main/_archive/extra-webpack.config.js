const { resolve, sep } = require('path');
const pkg = require('./package.json');
const webpack = require('webpack');

const name = `${pkg.config.org}${sep}${pkg.config.name}`;
const dest = resolve('..', 'app-main', 'public', 'static', name);
console.log('STATIC OUTPUT:', dest);

module.exports = (angularWebpackConfig, options) => {
  let compiler, config, micro;

  config = angularWebpackConfig;

  config.entry['app'] = [
    '/Users/c60575a/workspace/dev/experian/_archive/crosscore-ui/software-ui-crosscore-ui/src/main.ts',
  ];
  config.output.libraryTarget = 'umd';
  config.externals = [
    'polyfills',
    'runtime',
    'uikit',
    'uikit/dist/js/uikit-icons',
    'uikit/dist/css/uikit.css',
  ];

  //   // path: dest,
  //   // publicPath: dest,
  //   filename: '[name].js',
  //   library: 'bob',
  //   // libraryTarget: 'umd',
  //   libraryTarget: 'system',
  // };

  console.log('CONFIG:', config);

  // compiler = webpack(config);
  // compiler.run((err, stats) => {
  //   if (err) { return console.error(err); }
  //   console.log(stats);
  // });
  // process.exit ();

  return config;
}
