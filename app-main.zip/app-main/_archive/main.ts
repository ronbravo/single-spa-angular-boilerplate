console.log('**** APPP START ****')

import 'polyfills';
import 'runtime';
import uikit, { notification } from 'uikit';
// import icons from 'uikit/dist/js/uikit-icons';
import 'uikit/dist/css/uikit.css';

console.log ('WHAT:', uikit, notification);
// uikit.notification('Hello world.');

// const UIkit = uikit.default;
// const Icons = icons.default;

// // loads the Icon plugin
// UIkit.use(Icons);

// // components can be called from the imported UIkit reference
// UIkit.notification('Hello world.');
// console.log('huh?', UIkit);


// import { enableProdMode } from '@angular/core';
// import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

// import { AppModule } from './app/app.module';
// import { environment } from './environments/environment';

// // // add focus-within support for unsopported browsers
// // declare function focusWithin(e: Document): void;
// // focusWithin(document);


// if (environment.production) {
//   enableProdMode();
// }

// platformBrowserDynamic().bootstrapModule(AppModule)
//   .catch(err => console.error(err));
